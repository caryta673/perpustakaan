
<p></p>
<body>
    <center><font size="+1" face="arial">Sistem Informasi Perpustakaan</font></center>
    <center><font size="-1" face="arial">SMK N 6 SURAKARTA</font></center>
    <center><img src="perpusgambar.jpg" alt="perpusgambar" style="width:70%;min-height:100px"></center>
    
</body>